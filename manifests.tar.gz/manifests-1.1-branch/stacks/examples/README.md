This directory contains examples illustrating how users would leverage kustomize
to do various kubeflow kustomizations.